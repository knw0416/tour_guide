package com.example.nw.navermap;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.NetworkImageView;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Queue;
import java.util.Vector;

/**
 * Created by nw on 2017-05-28.
 */
public class SubActivity extends AppCompatActivity
        implements AdapterView.OnItemClickListener{
    public String courseId;
    public ApiExplorer api;
    String clientId = "xIjxpf_VlzOYWa206ROr";
    String clientSecret = "c2A6itzhNe";
    ArrayList<String> weather_time = new ArrayList<String>();
    ArrayList<String> spot = new ArrayList<String>();
    ArrayList<String> area = new ArrayList<String>();
    ArrayList<String> thema = new ArrayList<String>();
    String areaImgUrl = null;
    public static final int EMERGE_DISPALY = 100;

    public ArrayList<SpotInfo> mArray = new ArrayList<SpotInfo>();

    public static final String SPOTTAG = "SpotTag";
    protected Vector<JSONObject> mResult = new Vector<JSONObject>();
    protected ListView mList;
    protected SpotAdapter mAdapter;
    protected RequestQueue mQueue = null;
    public ImageLoader mImageLoader = null;
    private String areaname = null;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tour);
        mAdapter = new SpotAdapter(this, R.layout.spot_list, mArray);

        mList = (ListView)findViewById(R.id.list);

        mList.setAdapter(mAdapter);

        mList.setOnItemClickListener(this);

        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024); // 1MB
        Network network = new BasicNetwork(new HurlStack());
        mQueue = new RequestQueue(cache, network);
        mQueue.start();
        mImageLoader = new ImageLoader(mQueue,
                new LruBitmapCache(LruBitmapCache.getCacheSize(this)));
        Intent intent = getIntent();
        courseId = intent.getStringExtra("courseid");
        areaname = intent.getStringExtra("area");
        api = new ApiExplorer();
        api.execute();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent(this, RevActivity.class);
        intent.putExtra("spotname", mArray.get(position).getSpotName());
        intent.putExtra("imgURL", mArray.get(position).getImageURL());
        intent.putExtra("weather", api.getWeather().get(0));
//        intent.putExtra("favorite", mArray.get(position).getFavorite());
//        intent.putExtra("date", mArray.get(position).getDate());
        startActivityForResult(intent, EMERGE_DISPALY);
        //Toast.makeText(this, mArray[position], Toast.LENGTH_SHORT).show();
//        new AlertDialog.Builder(this)
//                .setTitle("������ ����")
//                .setMessage(mArray.get(position).getSong() + " �������� �����߽��ϴ�.")
//                .setPositiveButton("Ȯ��", null)
//                .show();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mQueue != null) {
            mQueue.cancelAll(SPOTTAG);
        }
    }
    protected void requestSpot()
    {
        HttpURLConnection con = null;
        for(int i=0; i<spot.size(); i++){
            StringBuffer response = new StringBuffer();
            try {
                String text = URLEncoder.encode(spot.get(i), "UTF-8");
                String apiURL = "https://openapi.naver.com/v1/search/image?query="+ text; // json ���
                //String apiURL = "https://openapi.naver.com/v1/search/blog.xml?query="+ text; // xml ���
                URL url = new URL(apiURL);
                con = (HttpURLConnection)url.openConnection();
                con.setRequestMethod("GET");
                con.setRequestProperty("X-Naver-Client-Id", clientId);
                con.setRequestProperty("X-Naver-Client-Secret", clientSecret);
                int responseCode = con.getResponseCode();
                BufferedReader br;
                if(responseCode==200) { // ���� ȣ��
                    br = new BufferedReader(new InputStreamReader(con.getInputStream()));
                } else {  // ���� �߻�
                    br = new BufferedReader(new InputStreamReader(con.getErrorStream()));
                }
                String inputLine;

                while ((inputLine = br.readLine()) != null) {
                    response.append(inputLine);
                }
                br.close();
                System.out.println(response.toString());
            } catch (Exception e) {
                System.out.println(e);
            }
            try {
                mResult.add(new JSONObject(response.toString()));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
    protected void requestArea()
    {
        HttpURLConnection con = null;
        StringBuffer response = new StringBuffer();
        try {
            String text = URLEncoder.encode(areaname, "UTF-8");
            String apiURL = "https://openapi.naver.com/v1/search/image?query="+ text; // json ���
            //String apiURL = "https://openapi.naver.com/v1/search/blog.xml?query="+ text; // xml ���
            URL url = new URL(apiURL);
            con = (HttpURLConnection)url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("X-Naver-Client-Id", clientId);
            con.setRequestProperty("X-Naver-Client-Secret", clientSecret);
            int responseCode = con.getResponseCode();
            BufferedReader br;
            if(responseCode==200) { // ���� ȣ��
                br = new BufferedReader(new InputStreamReader(con.getInputStream()));
            } else {  // ���� �߻�
                br = new BufferedReader(new InputStreamReader(con.getErrorStream()));
            }
            String inputLine;

            while ((inputLine = br.readLine()) != null) {
                response.append(inputLine);
            }
            br.close();
            System.out.println(response.toString());
        } catch (Exception e) {
            System.out.println(e);
        }
        JSONObject jsonOb = null;
        try {
            jsonOb = new JSONObject(response.toString());
            JSONArray jsonMainNode = jsonOb.getJSONArray("items");
            JSONObject jsonChildNode = jsonMainNode.getJSONObject(0);
            areaImgUrl = jsonChildNode.getString("link");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void drawList() {
        Log.d("????",Integer.toString(spot.size()));
        System.out.println("????"+spot.size());
        mArray.clear();
        String imgURL = null;
        for (int i = 0; i < spot.size(); i++) {
            try {
                JSONArray jsonMainNode = mResult.get(i).getJSONArray("items");
                if (jsonMainNode.length() != 0) {
                    JSONObject jsonChildNode = jsonMainNode.getJSONObject(0);
                    imgURL = jsonChildNode.getString("link");
                    Log.i("imgURL", imgURL);
                } else imgURL = null;
                mArray.add(new SpotInfo(spot.get(i), imgURL, thema.get(i)));
            }catch(JSONException | NullPointerException e){
                //Toast.makeText(getApplicationContext(),
                       // "Error" + e.toString(), Toast.LENGTH_LONG).show();
                //mResult.get(i) = null;
            }
        }
        mAdapter.notifyDataSetChanged();
    }

    public class SpotInfo {
        String spotName;
        String imageURL;
        String thema;
        public SpotInfo(String spotName, String imageURL, String thema) {
            this.spotName = spotName;
            this.imageURL = imageURL;
            this.thema = thema;
        }
        public String getSpotName() { return spotName; }
        public String getImageURL() {
            return imageURL;
        }
        public String getThema() { return thema; }
    }

    static class SpotViewHolder {
        TextView txSpotName;
        NetworkImageView imImage;
        TextView txThema;
    }

    public class SpotAdapter extends ArrayAdapter<SpotInfo> {

        public SpotAdapter(Context context, int resource, List<SpotInfo> objects) {
            super(context, resource, objects);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            SpotViewHolder holder;

            if (convertView == null) { // ó�� ������ ����
                convertView = getLayoutInflater().inflate(R.layout.spot_list, parent, false);

                holder = new SpotViewHolder();
                //TextView text = (TextView) convertView.findViewById(android.R.id.text1);
                holder.txSpotName = (TextView) convertView.findViewById(R.id.spot);
                holder.imImage = (NetworkImageView) convertView.findViewById(R.id.spot_image);
                holder.txThema = (TextView) convertView.findViewById(R.id.thema);
                convertView.setTag(holder);
            }
            else { // ��Ȱ��
                holder = (SpotViewHolder) convertView.getTag();
            }
            holder.txSpotName.setText(getItem(position).getSpotName());
            holder.imImage.setImageUrl(getItem(position).getImageURL(),
                    mImageLoader);
            holder.txThema.setText(getItem(position).getThema());
            return convertView;
        }
    }
    public class ApiExplorer extends AsyncTask<Integer, Integer, Integer> {
        public final static String ENDPOINT = "http://newsky2.kma.go.kr/service/TourSpotInfoService/SpotShrtData";
        public final static String ENDPOINT2 = "http://newsky2.kma.go.kr/service/TourSpotInfoService/SpotIdxData";
        public final static String KEY = "xRn%2B2vuY8tVScvXB9m8vmb1pYQu2evJIgZ2kJR6bj9Zgr4r4Z8vX2Iqxk%2B4mzEEJXynyGGPdNpfHuc%2Fjs56WMg%3D%3D";
        Vector<Element> list = new Vector<Element>();
        Vector<Element> list2 = new Vector<Element>();
        ArrayList<String> weather = new ArrayList<String>();
        ArrayList<String> temperature = new ArrayList<String>();
        ArrayList<String> pop = new ArrayList<String>();//: ����Ȯ��
        ArrayList<String> rhm = new ArrayList<String>();//: ����
        ArrayList<String> htIndex = new ArrayList<String>();//: ������
        ArrayList<String> dsIndex = new ArrayList<String>();//: ��������
        ArrayList<String> uvIndex = new ArrayList<String>();//: �ڿܼ�����
        ArrayList<String> wd = new ArrayList<String>();//: ǳ��
        ArrayList<String> ws = new ArrayList<String>();//: ǳ��
        public ArrayList<String> getArea(){return area;}
        public ArrayList<String> getWeather(){return weather;}
        public ArrayList<String> getSpot(){return spot;}
        public void setArea(ArrayList<String> area_p){area = area_p;}
        public void setWeather(ArrayList<String> weather_p){weather = weather_p;}
        public void setSpot(ArrayList<String> spot_p){spot = spot_p;}
        public void apiParserSearch() throws Exception {
            ArrayList<String> rvalUrl;
            rvalUrl = getURLParam(null);
            int scope = 12;
            try {
                System.out.println("connect");
                SAXBuilder parser = new SAXBuilder();
                System.out.println("SAX success");
                parser.setIgnoringElementContentWhitespace(true);
                for (int index = 0; index < scope + 1; index++) {
                    Document doc = parser.build(new URL(rvalUrl.get(index)));
                    Log.d("rvalurl", rvalUrl.get(index));
                    Element response = doc.getRootElement();
                    Element header = response.getChild("header");
                    Element resultMsg = header.getChild("resultMsg");
                    if(resultMsg.getValue().equals("LIMITED NUMBER OF SERVICE REQUESTS EXCEEDS ERROR.")){
                        Toast.makeText(SubActivity.this, "�������api ��û �Ǽ� �ʰ�", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    Element body = response.getChild("body");
                    Element items = body.getChild("items");
                    List<Element> item = items.getChildren("item");

                    if (item.size() == 0) {
                        System.out.println("empty");
                    } else {
                        for (int i = 0; i < item.size(); i++) {
                            if(index == 0)
                                list2.add(item.get(i));
                            else
                                list.add(item.get(i));
                        }
                        if(index!=0) {
                            Element sky = item.get(0).getChild("sky");
                            weather.add(sky.getValue());
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        public ArrayList<String> getURLParam(String search) throws UnsupportedEncodingException {
            String url = ENDPOINT + "?ServiceKey=" + KEY;
            String url2 = ENDPOINT2 + "?ServiceKey=" + KEY;
            ArrayList<String> endpointurl = new ArrayList<String>();
            long now = System.currentTimeMillis();
            Date date = new Date(now);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHH");
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            String getTime = sdf.format(cal.getTime());
            if ((Integer.parseInt(getTime) % 100) % 3 == 1){
                cal.add(Calendar.HOUR, -1);
                getTime = sdf.format(cal.getTime());
            }
            else if ((Integer.parseInt(getTime) % 100) % 3 == 2){
                cal.add(Calendar.HOUR, -2);
                getTime = sdf.format(cal.getTime());
            }
            endpointurl.add(url2 + "&HOUR=-23&COURSE_ID=" + courseId + "&pageNo=1&startPage=1&numOfRows=20&pageSize=10&CURRENT_DATE=" + getTime);
            for(int i=0; i<12; i++){
                weather_time.add(getTime);
                endpointurl.add(url + "&HOUR=-23&COURSE_ID=" + courseId + "&pageNo=1&startPage=1&numOfRows=20&pageSize=10&CURRENT_DATE=" + getTime);
                cal.add(Calendar.HOUR, 3);
                getTime = sdf.format(cal.getTime());
            }
            if (search != null) {
                url = url + "&yadmNm" + search;
            }
            return endpointurl;
        }

        public void getValues() {
            ArrayList<String> t_spot = new ArrayList<String>();
            for (Integer i = 0; i < list.size(); i++) {
                Element element = list.get(i);
                Element spotAreaName = element.getChild("spotAreaName");
                Element courseAreaName = element.getChild("courseAreaName");
                Element spotName = element.getChild("spotName");
                Element th3 = element.getChild("th3");
                Element thm = element.getChild("thema");
                Element elPop = element.getChild("pop");
                Element elRhm = element.getChild("rhm");
                Element elWd = element.getChild("wd");
                Element elWs = element.getChild("ws");
                temperature.add(th3.getValue());
                pop.add(elPop.getValue());
                rhm.add(elRhm.getValue());
                wd.add(elWd.getValue());
                ws.add(elWs.getValue());
                if(!t_spot.contains(spotName.getValue())){
                    t_spot.add(spotName.getValue());
                    thema.add(thm.getValue());
                }
                if (!area.contains(courseAreaName.getValue() + " " + spotAreaName.getValue())) {
                    area.add(courseAreaName.getValue() + " " + spotAreaName.getValue());
                }
            }
            for(int i=0; i<t_spot.size(); i++){
                String[] split = null;
                String[] split2 = null;
                if(t_spot.get(i).contains(")")){
                    split = t_spot.get(i).split("\\)");
                    if(split[1].contains("(")){
                        split2 = split[1].split("\\(");
                        spot.add(split2[0]);
                    }
                    else spot.add(split[1]);
                }
            }
            for(Integer i = 0; i < list2.size(); i++) {
                Element element = list2.get(i);
                Element elHtIndex = element.getChild("htIndex");
                Element elDsIndex = element.getChild("dsIndex");
                Element elUvIndex = element.getChild("uvIndex");
                htIndex.add(elHtIndex.getValue());
                dsIndex.add(elDsIndex.getValue());
                uvIndex.add(elUvIndex.getValue());
            }
        }

        @Override
        protected Integer doInBackground(Integer... integers) {
            try {
                apiParserSearch();
            } catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("myLog","error");
                e.printStackTrace();
            }
            getValues();
            requestArea();
            requestSpot();
            return null;
        }

        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);
            TextView txArea = (TextView) findViewById(R.id.area);
            ImageView weather_img[] = new ImageView[12];
            TextView weather_t[] = new TextView[12];
            TextView weather_d[] = new TextView[12];
            TextView temp[] = new TextView[12];
            NetworkImageView area_img = (NetworkImageView) findViewById(R.id.area_image);
            int resID[] = new int[12];
            for(Integer i=1; i<=12; i++){
                String resName = "@id/weather" + i.toString();
                resID[i-1] = getResources().getIdentifier(resName, "id", getPackageName());
                weather_img[i-1] = (ImageView) findViewById(resID[i-1]);
            }
            for(Integer i=1; i<=12; i++){
                String resName = "@id/weather_time" + i.toString();
                resID[i-1] = getResources().getIdentifier(resName, "id", getPackageName());
                weather_t[i-1] = (TextView) findViewById(resID[i-1]);
            }
            for(Integer i=1; i<=12; i++){
                String resName = "@id/weather_date" + i.toString();
                resID[i-1] = getResources().getIdentifier(resName, "id", getPackageName());
                weather_d[i-1] = (TextView) findViewById(resID[i-1]);
            }
            for(Integer i=1; i<=12; i++){
                String resName = "@id/temperature" + i.toString();
                resID[i-1] = getResources().getIdentifier(resName, "id", getPackageName());
                temp[i-1] = (TextView) findViewById(resID[i-1]);
            }
            txArea.setText(areaname);
            area_img.setImageUrl(areaImgUrl, mImageLoader);
            LinearLayout linearLayout = (LinearLayout)findViewById(R.id.tour_background);
            for(int i=0; i<1; i++){
                if(weather.size()==0){
                    Toast.makeText(SubActivity.this, "�������api ��û �Ǽ� �ʰ�", Toast.LENGTH_SHORT).show();
                    break;
                }
                if(weather.get(0).equals("1")) linearLayout.setBackgroundResource(R.drawable.sunny);
                else if(weather.get(0).equals("2")) linearLayout.setBackgroundResource(R.drawable.verylittlecloudy);
                else if (weather.get(0).equals("3")) linearLayout.setBackgroundResource(R.drawable.littlecloudy);
                else if(weather.get(0).equals("4")) linearLayout.setBackgroundResource(R.drawable.cloudy);
                else if(weather.get(0).equals("5")||weather.get(0).equals("6")||weather.get(0).equals("7")) linearLayout.setBackgroundResource(R.drawable.rainy);
                else if(weather.get(0).equals("8")) linearLayout.setBackgroundResource(R.drawable.snowy);
            }

            for(int i=0; i<12; i++){
                if(weather.size() <= i){
                    Toast.makeText(SubActivity.this, "�������api ��û �Ǽ� �ʰ�", Toast.LENGTH_SHORT).show();
                    break;
                }
                if(weather.get(i).equals("1")) weather_img[i].setImageResource(R.drawable.weather1);
                else if(weather.get(i).equals("2")) weather_img[i].setImageResource(R.drawable.weather2);
                else if(weather.get(i).equals("3")) weather_img[i].setImageResource(R.drawable.weather3);
                else if(weather.get(i).equals("4")) weather_img[i].setImageResource(R.drawable.weather4);
                else if(weather.get(i).equals("5")) weather_img[i].setImageResource(R.drawable.weather5);
                else if(weather.get(i).equals("6")||weather.get(0).equals("7")) weather_img[i].setImageResource(R.drawable.weather67);
                else if(weather.get(i).equals("8")) weather_img[i].setImageResource(R.drawable.weather8);
                weather_t[i].setText(Integer.toString((Integer.parseInt(weather_time.get(i))%100))+"��");
                if(i==0)
                    weather_d[i].setText(Integer.toString((Integer.parseInt(weather_time.get(i))%10000/100))+"��");
                else if(Integer.parseInt(weather_time.get(i))%100 == 0)
                    weather_d[i].setText(Integer.toString((Integer.parseInt(weather_time.get(i))%10000/100))+"��");
                temp[i].setText(temperature.get(i)+"��");
            }
            TextView txPop = (TextView) findViewById(R.id.pop);
            TextView txRhm = (TextView) findViewById(R.id.rhm);
            TextView txHtIndex = (TextView) findViewById(R.id.htIndex);
            TextView txDsIndex = (TextView) findViewById(R.id.dsIndex);
            TextView txUvIndex = (TextView) findViewById(R.id.uvIndex);
            TextView txWd = (TextView) findViewById(R.id.wd);
            TextView txWs = (TextView) findViewById(R.id.ws);
            for(int i=0; i<1; i++){
                if(pop.size()==0){
                    Toast.makeText(SubActivity.this, "�������api ��û �Ǽ� �ʰ�", Toast.LENGTH_SHORT).show();
                    break;
                }
                txPop.setText("����Ȯ�� : " + pop.get(0) + "%");
                txRhm.setText("���� : " + rhm.get(0) + "%");
                txWd.setText("ǳ�� : " + wd.get(0) + "��");
                txWs.setText("ǳ�� : " + ws.get(0) + "m/s");
            }


            txHtIndex.setText("ü���µ� : " + htIndex.get(0) + "��");
            txDsIndex.setText("�������� : " + dsIndex.get(0));
            String uvDegree = null;
            Double uvInx = Double.parseDouble(uvIndex.get(0));
            if(uvInx > 10) uvDegree = "����";
            else if(uvInx > 7) uvDegree = "�ſ����";
            else if(uvInx > 5) uvDegree = "����";
            else if(uvInx > 2) uvDegree = "����";
            else if(uvInx >= 0) uvDegree = "����";
            txUvIndex.setText("�ڿܼ����� : " + uvIndex.get(0) + " (" + uvDegree +")");

            drawList();
        }
    }
}
