package com.example.nw.navermap;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.sqlite.SQLiteStatement;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.HandlerThread;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.ShareActionProvider;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.NetworkImageView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Vector;
import java.util.logging.Handler;
import java.util.logging.LogRecord;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookActivity;
import com.facebook.FacebookCallback;
import com.facebook.FacebookDialog;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.HttpMethod;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.applinks.FacebookAppLinkResolver;
import com.facebook.internal.FacebookDialogFragment;
import com.facebook.internal.FacebookWebFallbackDialog;
import com.facebook.internal.WebDialog;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.facebook.share.ShareApi;
import com.facebook.share.internal.LikeContent;
import com.facebook.share.internal.LikeDialog;
import com.facebook.share.internal.LikeDialogFeature;
import com.facebook.share.internal.ShareFeedContent;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.model.SharePhoto;
import com.facebook.share.model.SharePhotoContent;
import com.facebook.share.widget.LikeView;
import com.facebook.share.widget.ShareDialog;

import bolts.AppLink;
import bolts.Task;

/**
 * Created by nw on 2017-05-31.
 */
public class RevActivity extends AppCompatActivity
        implements AdapterView.OnItemClickListener{
    String clientId = "xIjxpf_VlzOYWa206ROr";
    String clientSecret = "c2A6itzhNe";
    String spot = null;
    public ApiExplorer api;
    public static final int EMERGE_DISPALY = 100;

    public ArrayList<SpotInfo> mArray = new ArrayList<SpotInfo>();
    public ArrayList<FbInfo> mArray2 = new ArrayList<FbInfo>();
    public ArrayList<PostInfo> mArray3 = new ArrayList<PostInfo>();

    public static final String SPOTTAG = "SpotTag";
    protected JSONObject mResult = null;
    protected ListView mList;
    protected SpotAdapter mAdapter;
    protected RequestQueue mQueue = null;
    protected JSONObject mResult2 = null;
    protected ListView mList2;
    protected FbAdapter mAdapter2;
    protected RequestQueue mQueue2 = null;
    public ImageLoader mImageLoader = null;
    protected JSONObject mResult3 = null;
    protected ListView mList3;
    protected PostAdapter mAdapter3;
    protected JSONObject mResult4 = null;
    protected Vector<JSONObject> mResult5 = new Vector<JSONObject>();
    private CallbackManager callbackManager;

    private Button btnTakePicture;
    private String imagePath;
    private Bitmap bitmap = null;
    private Button fbposting;
    Activity act;
    public static final String FBTAG = "FbTag";
    private String FbAccessToken = "1290234924407757|2Wm4FVdxsyj64jNqCC4JA9cM3EU";
    private String FbGraphUrl = "https://graph.facebook.com";
    private String FbId;
    private String GroupId = "1685956785034523";
    ArrayList<String> postid = new ArrayList<String>();
    private Button Refresh;
    int postsize = 0;
    int refreshcode = 0;
    public RefreshExplorer refreshExplorer;
    String refreshId = null;
    String check_id = null;
    ArrayList<String> matched_id = new ArrayList<String>();
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FacebookSdk.sdkInitialize(getApplicationContext());
        AppEventsLogger.activateApp(this);
        setContentView(R.layout.activity_review);
        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024); // 1MB
        Network network = new BasicNetwork(new HurlStack());
        mQueue = new RequestQueue(cache, network);
        mQueue.start();
        mImageLoader = new ImageLoader(mQueue,
                new LruBitmapCache(LruBitmapCache.getCacheSize(this)));
        Refresh = (Button) findViewById(R.id.refresh);
        Refresh.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                refreshExplorer = new RefreshExplorer();
                refreshExplorer.execute();
            }
        });
        btnTakePicture = (Button) findViewById(R.id.btnTakePicture);
        btnTakePicture.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if(isExistsCameraApplication()){
                    Intent cameraApp = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    File picture = savePictureFile();
                    if(picture != null){
                        System.out.println("asdf");
                        cameraApp.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(picture));
                        startActivityForResult(cameraApp, 10000);
                    }
                }
            }
        });
        act = this;
        fbposting = (Button) findViewById(R.id.fbposting);
        fbposting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bitmap != null) {
                    SharePhoto photo = new SharePhoto.Builder()
                            .setBitmap(bitmap)
                            .build();
                    SharePhotoContent content = new SharePhotoContent.Builder()
                            .addPhoto(photo)
                            .build();
                    ShareDialog shareDialog = new ShareDialog(act);
                    shareDialog.show(content);
                    bitmap = null;
                } else{
                    Intent intent = new Intent(Intent.ACTION_PICK);
                    intent.setType(android.provider.MediaStore.Images.Media.CONTENT_TYPE);
                    intent.setData(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(intent, 999);
                }
                //act.finish();
            }
        });
        callbackManager = CallbackManager.Factory.create();
        LoginButton loginButton = (LoginButton) findViewById(R.id.login_button);
        loginButton.setReadPermissions(Arrays.asList("public_profile", "email"));
        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                GraphRequest graphRequest = GraphRequest.newMeRequest(loginResult.getAccessToken(), new GraphRequest.GraphJSONObjectCallback() {
                    @Override
                    public void onCompleted(JSONObject object, GraphResponse response) {
                        Log.v("result",object.toString());
                    }
                });

                Bundle parameters = new Bundle();
                parameters.putString("fields", "id,name,email,gender,birthday");
                graphRequest.setParameters(parameters);
                graphRequest.executeAsync();
            }
            @Override
            public void onError(FacebookException error) {

            }
            @Override
            public void onCancel() {

            }
        });
        GraphRequest graphRequest = GraphRequest.newMeRequest(AccessToken.getCurrentAccessToken(), new GraphRequest.GraphJSONObjectCallback() {
            @Override
            public void onCompleted(JSONObject object, GraphResponse response) {

            }
        });
        Bundle parameters = new Bundle();
        parameters.putString("fields", "name,id,cover,email");
        graphRequest.setParameters(parameters);
        graphRequest.executeAsync();
        mAdapter = new SpotAdapter(this, R.layout.blog_list, mArray);
        mList = (ListView)findViewById(R.id.list_blog);
        mList.setAdapter(mAdapter);
        mList.setOnItemClickListener(this);
        mAdapter2 = new FbAdapter(this, R.layout.fb_list, mArray2);
        mList2 = (ListView)findViewById(R.id.list_fb);
        mList2.setAdapter(mAdapter2);
        mList2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                String url = "https://www.facebook.com/" + mArray2.get(position).getId();
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            }
        });
        mAdapter3 = new PostAdapter(this, R.layout.post_list, mArray3);
        mList3 = (ListView)findViewById(R.id.list_post);
        mList3.setAdapter(mAdapter3);
        mList3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(mArray3.get(position).getLink()));
                startActivity(intent);
            }
        });
        Intent intent = getIntent();
        String imgURL = intent.getStringExtra("imgURL");
        String weather = intent.getStringExtra("weather");
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.pagebackground);
        if(weather.equals("1")) linearLayout.setBackgroundResource(R.drawable.sunny);
        else if(weather.equals("2")) linearLayout.setBackgroundResource(R.drawable.verylittlecloudy);
        else if (weather.equals("3")) linearLayout.setBackgroundResource(R.drawable.littlecloudy);
        else if(weather.equals("4")) linearLayout.setBackgroundResource(R.drawable.cloudy);
        else if(weather.equals("5")||weather.equals("6")||weather.equals("7")) linearLayout.setBackgroundResource(R.drawable.rainy);
        else if(weather.equals("8")) linearLayout.setBackgroundResource(R.drawable.snowy);
        spot = intent.getStringExtra("spotname");
        TextView tourname = (TextView) findViewById(R.id.tour_name);
        tourname.setText("  "+spot);
        api = new ApiExplorer();
        api.execute();
    }
    public class RefreshExplorer extends  AsyncTask<Integer, Integer, Integer>{
        @Override
        protected Integer doInBackground(Integer... integers) {
            requestPostId();
            try {
                JSONArray jsonMainNode = mResult3.getJSONArray("data");
                JSONObject jsonChildNode = jsonMainNode.getJSONObject(0);
                refreshId = jsonChildNode.getString("id");
                Log.i("refreshid", refreshId);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);
            if(!check_id.equals(refreshId)){
                InsertData task = new InsertData();
                task.execute(spot,refreshId);
            }
        }
    }
    class InsertData extends AsyncTask<String, Void, String>{
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            refreshcode = 1;
            api = new ApiExplorer();
            api.execute();
        }
        @Override
        protected String doInBackground(String... params) {
            String spot = (String)params[0];
            String postid = (String)params[1];

            String serverURL = "http://192.168.215.186/data_insert.php";
            String postParameters = "spot=" + spot + "&postid=" + postid;

            try {
                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                //httpURLConnection.setRequestProperty("content-type", "application/json");
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();

                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();

                int responseStatusCode = httpURLConnection.getResponseCode();

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }

                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }
                bufferedReader.close();
                return sb.toString();
            } catch (Exception e) {
                return new String("Error: " + e.getMessage());
            }
        }
    }
    private boolean isExistsCameraApplication(){
        PackageManager packageManager = getPackageManager();
        Intent cameraApp = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        List<ResolveInfo> cameraApps = packageManager.queryIntentActivities(cameraApp, PackageManager.MATCH_DEFAULT_ONLY);
        return cameraApps.size() > 0;
    }
    private File savePictureFile(){
        String timestamp = new SimpleDateFormat("yyyyMMdd HHmmss").format(new Date());
        String fileName = "IMG_" + timestamp;

        File pictureStorage = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "MYAPP/");

        if(!pictureStorage.exists()){
            pictureStorage.mkdirs();
        }
        try{
            File file = File.createTempFile(fileName, ".jpg", pictureStorage);
            imagePath = file.getAbsolutePath();System.out.println(imagePath);
            //���� ������ �������� �����Ѵ�
            Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            File f = new File(imagePath);
            Uri contentUri = Uri.fromFile(f);
            mediaScanIntent.setData(contentUri);
            this.sendBroadcast(mediaScanIntent);
            return file;
        } catch (IOException e){
            e.printStackTrace();
        }
        return null;
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 10000 && resultCode == RESULT_OK){
            BitmapFactory.Options factory = new BitmapFactory.Options();
            factory.inJustDecodeBounds = true;

            BitmapFactory.decodeFile(imagePath);

            factory.inJustDecodeBounds = false;
            factory.inPurgeable = true;

            bitmap = BitmapFactory.decodeFile(imagePath, factory);
        } else if(requestCode == 999 && resultCode == RESULT_OK){
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), data.getData());
                SharePhoto photo = new SharePhoto.Builder()
                        .setBitmap(bitmap)
                        .build();
                SharePhotoContent content = new SharePhotoContent.Builder()
                        .addPhoto(photo)
                        .build();
                ShareDialog shareDialog = new ShareDialog(act);
                shareDialog.show(content);
                bitmap = null;
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        else callbackManager.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        String url = mArray.get(position).getLink().replace("amp;","");
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }

    @Override
    protected void onStop() {
        super.onStop();
//        if (mQueue != null) {
//            mQueue.cancelAll(SPOTTAG);
//        }
//        if(mQueue2 != null){
//            mQueue2.cancelAll(FBTAG);
//        }
    }
    protected void requestDb()
    {
        StringBuffer response = new StringBuffer();
        try {
            String apiURL = "http://192.168.215.186/selectjson.php";
            URL url = new URL(apiURL);
            HttpURLConnection con = (HttpURLConnection)url.openConnection();
            con.setRequestMethod("GET");
            int responseCode = con.getResponseCode();
            BufferedReader br;
            if(responseCode==200) { // ���� ȣ��
                br = new BufferedReader(new InputStreamReader(con.getInputStream()));
            } else {  // ���� �߻�
                br = new BufferedReader(new InputStreamReader(con.getErrorStream()));
            }
            String inputLine;

            while ((inputLine = br.readLine()) != null) {
                response.append(inputLine);
            }
            br.close();
            System.out.println(response.toString());
        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            mResult4 = new JSONObject(response.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        drawDbList();
    }
    public void drawDbList() {
        postid.clear();
        try {
            JSONArray jsonMainNode = mResult4.getJSONArray("list");
            for (int i = 0; i < jsonMainNode.length(); i++) {
                JSONObject jsonChildNode = jsonMainNode.getJSONObject(i);
                String t_spot = jsonChildNode.getString("spot");
                Log.i("spot", t_spot);
                if(t_spot.equals(spot)){
                    postid.add(jsonChildNode.getString("postid"));
                    //Log.i("postid", postid.get(i));
                }
            }
        } catch (JSONException | NullPointerException e) {
            Toast.makeText(getApplicationContext(),
                    "Error" + e.toString(),Toast.LENGTH_LONG).show();
            mResult4 = null;
        }
    }
    protected void requestPost()
    {
        mResult5.clear();
        for(int i=0; i<matched_id.size(); i++){
            StringBuffer response = new StringBuffer();
            try {
                String apiURL = FbGraphUrl+"/v2.8/"+ matched_id.get(i) +"?access_token=" + FbAccessToken + "&fields=link,picture,message,updated_time"; // json ���
                URL url = new URL(apiURL);
                HttpURLConnection con = (HttpURLConnection)url.openConnection();
                con.setRequestMethod("GET");
                int responseCode = con.getResponseCode();
                BufferedReader br;
                if(responseCode==200) { // ���� ȣ��
                    br = new BufferedReader(new InputStreamReader(con.getInputStream()));
                } else {  // ���� �߻�
                    br = new BufferedReader(new InputStreamReader(con.getErrorStream()));
                }
                String inputLine;
                while ((inputLine = br.readLine()) != null) {
                    response.append(inputLine);
                }
                br.close();
                System.out.println(response.toString());
            } catch (Exception e) {
                System.out.println(e);
            }
            try {
                mResult5.add(new JSONObject(response.toString()));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

    }
    protected void drawPostList(){
        mArray3.clear();
        try {
            for (int i = 0; i < matched_id.size(); i++) {
                String link = mResult5.get(i).getString("link");
                Log.i("link", link);
                String picture = mResult5.get(i).getString("picture");
                Log.i("picture", picture);
                String message = mResult5.get(i).getString("message");
                Log.i("message", message);
                String updated_time = mResult5.get(i).getString("updated_time");
                Log.i("updated_time",updated_time);
                mArray3.add(new PostInfo(link,picture,message, updated_time));
            }
        } catch (JSONException | NullPointerException e) {
            Log.d("qqqq","qqqq");
            Toast.makeText(getApplicationContext(),
                    "Error" + e.toString(),Toast.LENGTH_LONG).show();
            mResult5 = null;
        }
        mAdapter3.notifyDataSetChanged();
    }
    protected void requestPostId()
    {
        StringBuffer response = new StringBuffer();
        try {
            String apiURL = FbGraphUrl+"/v2.8/"+ GroupId +"/feed?access_token=" + FbAccessToken; // json ���
            URL url = new URL(apiURL);
            HttpURLConnection con = (HttpURLConnection)url.openConnection();
            con.setRequestMethod("GET");
            int responseCode = con.getResponseCode();
            BufferedReader br;
            if(responseCode==200) { // ���� ȣ��
                br = new BufferedReader(new InputStreamReader(con.getInputStream()));
            } else {  // ���� �߻�
                br = new BufferedReader(new InputStreamReader(con.getErrorStream()));
            }
            String inputLine;
            while ((inputLine = br.readLine()) != null) {
                response.append(inputLine);
            }
            br.close();
            System.out.println(response.toString());
        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            mResult3 = new JSONObject(response.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    protected void drawPostIdList(){
        matched_id.clear();
        try {
            JSONArray jsonMainNode = mResult3.getJSONArray("data");
            for (int i = 0; i < jsonMainNode.length(); i++) {
                JSONObject jsonChildNode = jsonMainNode.getJSONObject(i);
                String id = jsonChildNode.getString("id");
                Log.i("id", id);
                if(i==0) check_id = id;
                for(int j=0; j< postid.size(); j++){
                    if(id.equals(postid.get(j))){
                        matched_id.add(id);
                    }
                }
            }
        } catch (JSONException | NullPointerException e) {
            Log.d("qqqq","qqqq");
            Toast.makeText(getApplicationContext(),
                    "Error" + e.toString(),Toast.LENGTH_LONG).show();
            mResult3 = null;
        }
    }
    public class PostInfo {
        String link;
        String picture;
        String message;
        String updated_time;
        public PostInfo(String link,String picture,String message, String updated_time) {
            this.link = link;
            this.picture = picture;
            this.message = message;
            this.updated_time = updated_time;
        }
        public String getLink(){return link;}
        public String getPicture(){return picture;}
        public String getMessage() { return message; }
        public String getUpdated_time() { return updated_time; }
    }
    static class PostViewHolder {
        NetworkImageView imPicture;
        TextView txMessage;
        TextView txUpdated_time;
    }
    public class PostAdapter extends ArrayAdapter<PostInfo> {
        public PostAdapter(Context context, int resource, List<PostInfo> objects) {
            super(context, resource, objects);
        }
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            PostViewHolder holder;
            if (convertView == null) { // ó�� ������ ����
                convertView = getLayoutInflater().inflate(R.layout.post_list, parent, false);

                holder = new PostViewHolder();
                holder.imPicture = (NetworkImageView) convertView.findViewById(R.id.picture);
                holder.txMessage = (TextView) convertView.findViewById(R.id.message);
                holder.txUpdated_time = (TextView) convertView.findViewById(R.id.updated_time);

                convertView.setTag(holder);
            }
            else { // ��Ȱ��
                holder = (PostViewHolder) convertView.getTag();
            }
            holder.imPicture.setImageUrl(getItem(position).getPicture(), mImageLoader);
            holder.txMessage.setText(getItem(position).getMessage());
            holder.txUpdated_time.setText(getItem(position).getUpdated_time());
            return convertView;
        }
    }
    protected void requestFb()
    {
        StringBuffer response = new StringBuffer();
        try {
            String text = URLEncoder.encode(spot, "UTF-8");
            String apiURL = FbGraphUrl+"/search?q="+ text+"&type=page&access_token=" + FbAccessToken; // json ���
            URL url = new URL(apiURL);
            HttpURLConnection con = (HttpURLConnection)url.openConnection();
            con.setRequestMethod("GET");
            int responseCode = con.getResponseCode();
            BufferedReader br;
            if(responseCode==200) { // ���� ȣ��
                br = new BufferedReader(new InputStreamReader(con.getInputStream()));
            } else {  // ���� �߻�
                br = new BufferedReader(new InputStreamReader(con.getErrorStream()));
            }
            String inputLine;

            while ((inputLine = br.readLine()) != null) {
                response.append(inputLine);
            }
            br.close();
            System.out.println(response.toString());
        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            mResult2 = new JSONObject(response.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    protected void drawFbList(){
        mArray2.clear();
        try {
            JSONArray jsonMainNode = mResult2.getJSONArray("data");

            for (int i = 0; i < jsonMainNode.length(); i++) {
                JSONObject jsonChildNode = jsonMainNode.getJSONObject(i);
                String name = jsonChildNode.getString("name");
                Log.i("name", name);
                String id = jsonChildNode.getString("id");
                Log.i("id", id);
                mArray2.add(new FbInfo(name, id));
            }
        } catch (JSONException | NullPointerException e) {
            Toast.makeText(getApplicationContext(),
                    "Error" + e.toString(),Toast.LENGTH_LONG).show();
            mResult2 = null;
        }

        mAdapter2.notifyDataSetChanged();
    }
    public class FbInfo {
        String name;
        String id;
        public FbInfo(String name, String id) {
            this.name = name;
            this.id = id;
        }
        public String getName() { return name; }
        public String getId() { return id; }
    }

    static class FbViewHolder {
        TextView txName;
    }
    public class FbAdapter extends ArrayAdapter<FbInfo> {
        public FbAdapter(Context context, int resource, List<FbInfo> objects) {
            super(context, resource, objects);
        }
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            FbViewHolder holder;
            if (convertView == null) { // ó�� ������ ����
                convertView = getLayoutInflater().inflate(R.layout.fb_list, parent, false);

                holder = new FbViewHolder();
                holder.txName = (TextView) convertView.findViewById(R.id.page_name);

                convertView.setTag(holder);
            }
            else { // ��Ȱ��
                holder = (FbViewHolder) convertView.getTag();
            }
            holder.txName.setText(getItem(position).getName());
            return convertView;
        }
    }
    protected void requestSpot()
    {
        StringBuffer response = new StringBuffer();
        try {
            String text = URLEncoder.encode(spot, "UTF-8");
            String apiURL = "https://openapi.naver.com/v1/search/blog?query="+ text; // json ���
            //String apiURL = "https://openapi.naver.com/v1/search/blog.xml?query="+ text; // xml ���
            URL url = new URL(apiURL);
            HttpURLConnection con = (HttpURLConnection)url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("X-Naver-Client-Id", clientId);
            con.setRequestProperty("X-Naver-Client-Secret", clientSecret);
            int responseCode = con.getResponseCode();
            BufferedReader br;
            if(responseCode==200) { // ���� ȣ��
                br = new BufferedReader(new InputStreamReader(con.getInputStream()));
            } else {  // ���� �߻�
                br = new BufferedReader(new InputStreamReader(con.getErrorStream()));
            }
            String inputLine;

            while ((inputLine = br.readLine()) != null) {
                response.append(inputLine);
            }
            br.close();
            System.out.println(response.toString());
        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            mResult = new JSONObject(response.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void drawList() {
        mArray.clear();
        try {
            JSONArray jsonMainNode = mResult.getJSONArray("items");
            for (int i = 0; i < jsonMainNode.length(); i++) {
                JSONObject jsonChildNode = jsonMainNode.getJSONObject(i);
                String title = jsonChildNode.getString("title").replace("<b>","");
                title = title.replace("</b>","");
                title = title.replace("&amp;","");
                Log.i("title", title);
                String postdate = jsonChildNode.getString("postdate");
                Log.i("postdate", postdate);
                String link = jsonChildNode.getString("link");
                Log.i("link", link);
                mArray.add(new SpotInfo(title, postdate, link));
            }
        } catch (JSONException | NullPointerException e) {
            Toast.makeText(getApplicationContext(),
                    "Error" + e.toString(),Toast.LENGTH_LONG).show();
            mResult = null;
        }

        mAdapter.notifyDataSetChanged();
    }

    public class SpotInfo {
        String title;
        String postdate;
        String link;
        public SpotInfo(String title, String postdate, String link) {
            this.title = title;
            this.postdate = postdate;
            this.link = link;
        }
        public String getTitle() { return title; }
        public String getPostdate() { return postdate; }
        public String getLink() { return link; }
    }

    static class SpotViewHolder {
        TextView txTitle;
        TextView txPostdate;
    }

    public class SpotAdapter extends ArrayAdapter<SpotInfo> {

        public SpotAdapter(Context context, int resource, List<SpotInfo> objects) {
            super(context, resource, objects);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            SpotViewHolder holder;

            if (convertView == null) { // ó�� ������ ����
                convertView = getLayoutInflater().inflate(R.layout.blog_list, parent, false);

                holder = new SpotViewHolder();
                //TextView text = (TextView) convertView.findViewById(android.R.id.text1);
                holder.txTitle = (TextView) convertView.findViewById(R.id.blog_title);
                holder.txPostdate = (TextView) convertView.findViewById(R.id.postdate);

                convertView.setTag(holder);
            }
            else { // ��Ȱ��
                holder = (SpotViewHolder) convertView.getTag();
            }

            holder.txTitle.setText(getItem(position).getTitle());
            holder.txPostdate.setText(getItem(position).getPostdate());
            return convertView;
        }
    }
    public class ApiExplorer extends AsyncTask<Integer, Integer, Integer> {
        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);
            if(refreshcode==0){
                drawList();
                drawFbList();
            }
            drawPostList();
            refreshcode = 0;
        }

        @Override
        protected Integer doInBackground(Integer... integers) {
            if(refreshcode == 0){
                requestSpot();
                requestFb();
            }
            requestDb();
            requestPostId();
            drawPostIdList();
            requestPost();
            return null;
        }
    }
}
