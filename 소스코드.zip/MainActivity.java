package com.example.nw.navermap;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.Settings;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.facebook.FacebookSdk;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.login.LoginManager;
import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;
import com.nhn.android.maps.NMapActivity;
import com.nhn.android.maps.NMapCompassManager;
import com.nhn.android.maps.NMapController;
import com.nhn.android.maps.NMapLocationManager;
import com.nhn.android.maps.NMapOverlay;
import com.nhn.android.maps.NMapOverlayItem;
import com.nhn.android.maps.NMapView;
import com.nhn.android.maps.maplib.NGeoPoint;
import com.nhn.android.maps.nmapmodel.NMapError;
import com.nhn.android.maps.nmapmodel.NMapPlacemark;
import com.nhn.android.maps.overlay.NMapPOIdata;
import com.nhn.android.maps.overlay.NMapPOIitem;
import com.nhn.android.mapviewer.overlay.NMapCalloutOverlay;
import com.nhn.android.mapviewer.overlay.NMapMyLocationOverlay;
import com.nhn.android.mapviewer.overlay.NMapOverlayManager;
import com.nhn.android.mapviewer.overlay.NMapPOIdataOverlay;
import com.nhn.android.mapviewer.overlay.NMapResourceProvider;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Vector;

public class MainActivity extends NMapActivity implements
        NMapView.OnMapStateChangeListener, NMapOverlayManager.OnCalloutOverlayListener {
    private NMapView mMapView;// ���� ȭ�� View
    private final String CLIENT_ID = "_eE_UTjjPOo6TEfCIGsy";
    NMapController mMapController = null;
    // ���� �߰��� ���̾ƿ�
    LinearLayout MapContainer;
    // ���������� ���ҽ��� �����ϱ� ���� ��ü
//	NMapViewerResourceProvider mMapViewerResourceProvider = null;
    // �������� ������
    NMapViewerResourceProvider mMapViewerResourceProvider = null;//NMapViewerResourceProvider Ŭ���� ���
    NMapOverlayManager mOverlayManager; //���� ���� ǥ�õǴ� �������� ��ü�� �����Ѵ�.
    NMapPOIdataOverlay.OnStateChangeListener onPOIdataStateChangeListener = null; //POI �������� ���� ���� ���� �� ȣ��Ǵ� �ݹ� �������̽��� �����Ѵ�.
    NMapOverlayManager.OnCalloutOverlayListener onCalloutOverlayListener; //��ǳ�� �������� ��ü ���� �� ȣ��Ǵ� �ݹ� �������̽��� �����Ѵ�.
    NMapLocationManager mMapLocationManager; //�ܸ����� ���� ��ġ Ž�� ����� ����ϱ� ���� Ŭ�����̴�.
    //NMapLocationManager.OnLocationChangeListener onMyLocationChangeListener;
    NMapCompassManager mMapCompassManager; //�ܸ����� ��ħ�� ����� ����ϱ� ���� Ŭ�����̴�.
    NMapMyLocationOverlay mMyLocationOverlay; //���� ���� ���� ��ġ�� ǥ���ϴ� �������� Ŭ�����̸� NMapOverlay Ŭ������ ����Ѵ�.
    NMapPOIitem.ResourceProvider mMapPOIitemResourceProvider;
    private ApiExplorer api;
    public SharedPreferences pref;
    Vector<NGeoPoint> location = new Vector<NGeoPoint>();

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    //private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //StrictMode.enableDefaults();
        //���̹� ������ �ֱ� ���� LinearLayout ������Ʈ
        MapContainer = (LinearLayout) findViewById(R.id.map);
        //���̹� ���� ��ü ����
        mMapView = new NMapView(this);
        // ���� ��ü�κ��� ��Ʈ�ѷ� ����
        mMapController = mMapView.getMapController();

        mMapView.setClientId(CLIENT_ID); //Ŭ���̾�Ʈ ���̵� �� ����
        //������ ���̹� ���� ��ü�� LinearLayout�� �߰���Ų��.
        MapContainer.addView(mMapView);
        //������ ��ġ�� �� �ֵ��� �ɼ� Ȱ��ȭ
        mMapView.setClickable(true);

        //create resource provider(�������� ��ü)
        mMapViewerResourceProvider = new NMapViewerResourceProvider(this); //NMapViewerResourceProvider Ŭ���� ���
        mOverlayManager = new NMapOverlayManager(this, mMapView, mMapViewerResourceProvider); //�������� ��ü�� ȭ�鿡 ǥ���ϱ� ���Ͽ� NMapResourceProvider Ŭ������ ��ӹ��� resourceProvider ��ü�� �����Ѵ�
        mOverlayManager.setOnCalloutOverlayListener(onCalloutOverlayListener); //��ǳ�� �������� ��ü ���� �� ȣ��Ǵ� �ݹ� �������̽��� �����Ѵ�.

        // Ȯ��/��Ҹ� ���� �� ��Ʈ�ѷ� ǥ�� �ɼ� Ȱ��ȭ
        //mMapView.setBuiltInZoomControls(true, null);
        // set data provider listener
        super.setMapDataProviderListener(onDataProviderListener);//���� ���̺귯������ �����ϴ� ���� API ȣ�� �� ���信 ���� �ݹ� �������̽��� �����Ѵ�.
        // ������ ���� ���� ���� �̺�Ʈ ����
        mMapView.setOnMapStateChangeListener(this);
        mMapView.setEnabled(true);
        mMapView.setFocusable(true);
        mMapView.setFocusableInTouchMode(true);
        mMapView.requestFocus();

        api = new ApiExplorer();
        pref = getSharedPreferences("pref", MODE_PRIVATE);//**��带 ã�ƺ���.
        long now = System.currentTimeMillis();
        Date date = new Date(now);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhh");
        String getTime = sdf.format(date);
        String savedTime = pref.getString("getTime", "");
        if (pref.contains("*")) {
            if (Integer.parseInt(getTime) >= Integer.parseInt(savedTime) + 3) {
                getLocationPre();
                api.execute(0);
            } else {
                getPreferences();
                drawButton();
            }
        } else {
            api.execute(0);
        }
        Log.d("myLog", "sharedpref���*");
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        //client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    private void getLocationPre() {
        int locationSize = pref.getInt("locationSize", 0);
        int lat, lng;
        for (Integer i = 0; i < locationSize; i++) {
            lat = pref.getInt("location" + i.toString() + "lat", 0);
            lng = pref.getInt("location" + i.toString() + "lng", 0);
            location.add(new NGeoPoint(lat, lng));
        }
    }

    private void getPreferences() {
        int locationSize = pref.getInt("locationSize", 0);
        ArrayList<String> area_t = new ArrayList<String>();
        ArrayList<String> weather_t = new ArrayList<String>();
        ArrayList<String> id_t = new ArrayList<String>();
        ArrayList<String> course_t = new ArrayList<String>();
        int lat, lng;
        Log.d("locationSize", Integer.toString(locationSize));
        for (Integer i = 0; i < locationSize; i++) {
            lat = pref.getInt("location" + i.toString() + "lat", 0);
            lng = pref.getInt("location" + i.toString() + "lng", 0);
            location.add(new NGeoPoint(lat, lng));
            area_t.add(pref.getString("area" + i.toString(), ""));
            weather_t.add(pref.getString("weather" + i.toString(), ""));
            id_t.add(pref.getString("courseId" + i.toString(), ""));
            course_t.add(pref.getString("courseName" + i.toString(), ""));
        }
        api.setArea(area_t);
        api.setWeather(weather_t);
        api.setCourseId(id_t);
        api.setCourseName(course_t);
    }

    @Override
    public NMapCalloutOverlay onCreateCalloutOverlay(NMapOverlay nMapOverlay, NMapOverlayItem nMapOverlayItem, Rect rect) {
        return null;
    }

    @Override
    public void onMapInitHandler(NMapView nMapView, NMapError nMapError) {
        if (nMapError == null) { // success
            startMyLocation();//������ġ�� �̵�
        } else {
            Log.e("NMAP",
                    "onMapInitHandler: error=" + nMapError.toString());
        }
    }

    @Override
    public void onMapCenterChange(NMapView nMapView, NGeoPoint nGeoPoint) {

    }

    @Override
    public void onMapCenterChangeFine(NMapView nMapView) {

    }

    @Override
    public void onZoomLevelChange(NMapView nMapView, int i) {

    }

    @Override
    public void onAnimationStateChange(NMapView nMapView, int i, int i1) {

    }

    private void startMyLocation() {
        mMapLocationManager = new NMapLocationManager(this);
        mMapLocationManager
                .setOnLocationChangeListener(onMyLocationChangeListener);
        boolean isMyLocationEnabled = mMapLocationManager
                .enableMyLocation(true);
        if (!isMyLocationEnabled) {
            Toast.makeText(
                    MainActivity.this,
                    "Please enable a My Location source in system settings",
                    Toast.LENGTH_LONG).show();
            Intent goToSettings = new Intent(
                    Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivity(goToSettings);
            finish();
        } else {

        }
    }

    private void stopMyLocation() {
        if (mMyLocationOverlay != null) {
            mMapLocationManager.disableMyLocation();
            if (mMapView.isAutoRotateEnabled()) {
                mMyLocationOverlay.setCompassHeadingVisible(false);
                mMapCompassManager.disableCompass();
                mMapView.setAutoRotateEnabled(false, false);
                MapContainer.requestLayout();
            }
        }
    }

    private final OnDataProviderListener onDataProviderListener = new OnDataProviderListener() {
        @Override
        public void onReverseGeocoderResponse(NMapPlacemark placeMark, NMapError errInfo) {
            if (errInfo != null) {
                Log.e("myLog", "Failed to findPlacemarkAtLocation: error=" + errInfo.toString());
                Toast.makeText(MainActivity.this, errInfo.toString(), Toast.LENGTH_LONG).show();
                return;
            } else {
                //Toast.makeText(MainActivity.this, placeMark.toString(), Toast.LENGTH_LONG).show();
            }
        }
    };
    private final NMapLocationManager.OnLocationChangeListener onMyLocationChangeListener = new NMapLocationManager.OnLocationChangeListener() {
        @Override
        public boolean onLocationChanged(NMapLocationManager locationManager,
                                         NGeoPoint myLocation) {
            if (mMapController != null) {
                mMapController.animateTo(myLocation);
            }
            Log.d("myLog", "myLocation  lat " + myLocation.getLatitude());
            Log.d("myLog", "myLocation  lng " + myLocation.getLongitude());
            findPlacemarkAtLocation(myLocation.getLongitude(), myLocation.getLatitude());
            //�����浵�� �ּҷ� ��ȯ
            return true;
        }

        @Override
        public void onLocationUpdateTimeout(NMapLocationManager nMapLocationManager) {
            Toast.makeText(MainActivity.this,
                    "Your current location is temporarily unavailable.",
                    Toast.LENGTH_LONG).show();
        }

        @Override
        public void onLocationUnavailableArea(NMapLocationManager nMapLocationManager, NGeoPoint nGeoPoint) {
            Toast.makeText(MainActivity.this,
                    "Your current location is unavailable area.",
                    Toast.LENGTH_LONG).show();
            stopMyLocation();
        }
    };

    public void findGeoPoint() {
        ArrayList<String> area = api.getArea();
        String address;
        Geocoder geocoder = new Geocoder(this);
        Address addr;
        SharedPreferences.Editor editor = pref.edit();
        try {
            for (Integer i = 0; i < area.size(); i++) {
                address = area.get(i);
                List<Address> listAddress = geocoder.getFromLocationName(address, 1);
                if (listAddress.size() > 0) { // �ּҰ��� ���� �ϸ�
                    addr = listAddress.get(0); // Address���·�
                    int lat = (int) (addr.getLatitude() * 1E6);
                    int lng = (int) (addr.getLongitude() * 1E6);

                    location.add(new NGeoPoint(lat, lng));
                    editor.putInt("location" + i.toString() + "lat", lat);
                    editor.putInt("location" + i.toString() + "lng", lng);
                    Log.d("TAG", "�ּҷκ��� ����� ���� : " + lat + ", �浵 : " + lng);
                } else {
                    location.add(new NGeoPoint(0, 0));
                }
            }
            editor.putInt("locationSize", area.size());
            editor.commit();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void drawButton() {
        Vector<NMapPOIitem> item = new Vector<NMapPOIitem>();
        ArrayList<String> area = api.getArea();
        int temp = location.size();
        int scope = temp;
        int markerId = NMapPOIflagType.PIN;
        int count = 0;
        for (int i = 0; i < temp; i++) {
            if (location.get(i).getLatitude() == 0) scope--;
        }
        NMapPOIdata poiData = new NMapPOIdata(scope, mMapViewerResourceProvider); //��ü POI �������� ������ NMapResourceProvider�� ��ӹ��� Ŭ������ ���ڷ� �����Ѵ�.
        poiData.beginPOIdata(scope); //POI ������ �߰��� �����Ѵ�.

        for (int i = 0; i < temp; i++) {
            //******************************
            if (location.get(i).getLatitude() != 0) {
                Log.d("asdf1", api.getWeather().get(i));
                if (api.getWeather().get(i).equals("1"))
                    markerId = NMapPOIflagType.PIN1;
                else if (api.getWeather().get(i).equals("2"))
                    markerId = NMapPOIflagType.PIN2;
                else if (api.getWeather().get(i).equals("3"))
                    markerId = NMapPOIflagType.PIN3;
                else if (api.getWeather().get(i).equals("4"))
                    markerId = NMapPOIflagType.PIN4;
                else if (api.getWeather().get(i).equals("5"))
                    markerId = NMapPOIflagType.PIN5;
                else if (api.getWeather().get(i).equals("6") || api.getWeather().get(i).equals("7"))
                    markerId = NMapPOIflagType.PIN6;
                else if (api.getWeather().get(i).equals("8"))
                    markerId = NMapPOIflagType.PIN7;

                Log.d("�����浵", location.get(i).longitude + " " + location.get(i).latitude);
                item.add(poiData.addPOIitem(location.get(i).latitude, location.get(i).longitude, area.get(i), markerId, i));//POI������ ����
                item.get(count).setRightAccessory(true, NMapPOIflagType.CLICKABLE_ARROW); //��Ŀ ���� �� ǥ�õǴ� ��ǳ���� ������ �������� �����Ѵ�.
                item.get(count).hasRightAccessory(); //��Ŀ ���� �� ǥ�õǴ� ��ǳ���� ������ ������ ���� ���θ� ��ȯ�Ѵ�.
                item.get(count).setRightButton(true); //��Ŀ ���� �� ǥ�õǴ� ��ǳ���� ������ ��ư�� �����Ѵ�.
                item.get(count).showRightButton(); //��Ŀ ���� �� ǥ�õǴ� ��ǳ���� ������ ��ư ���� ���θ� ��ȯ�Ѵ�.
                count++;

            }
        }


//        NMapPOIitem item2 = poiData.addPOIitem(126.914925, 37.528728, "��ȸ�ǿ�ȸ��", markerId, 0);
//        item2.setRightAccessory(true, NMapPOIflagType.CLICKABLE_ARROW);
//        item2.hasRightAccessory();
//        item2.setRightButton(true);
//        item2.showRightButton();

        //poiData.addPOIitem(126.872772, 37.546848, "KB�������� ��â�� ���� ��", markerId, 0); //�浵���� ��ǥ �Է����ָ�, �� ��ǥ�� ǥ�õ�
        //poiData.addPOIitem(126.914925, 37.528728, "��ȸ�ǿ�ȸ��", markerId, 0); //�浵���� ��ǥ �Է����ָ�, �� ��ǥ�� ǥ�õ�
        poiData.endPOIdata(); //POI ������ �߰��� �����Ѵ�.
        NMapPOIdataOverlay poiDataOverlay = mOverlayManager.createPOIdataOverlay(poiData, null); //POI �����͸� ���ڷ� �����Ͽ� NMapPOIdataOverlay ��ü�� �����Ѵ�.
        //poiDataOverlay.showAllPOIdata(0); //POI �����Ͱ� ��� ȭ�鿡 ǥ�õǵ��� ���� ��ô ���� �� ���� �߽��� �����Ѵ�. zoomLevel�� 0�� �ƴϸ� ������ ���� ��ô �������� ���� �߽ɸ� �����Ѵ�.
        poiDataOverlay.setOnStateChangeListener(new NMapPOIdataOverlay.OnStateChangeListener() {
            @Override
            public void onFocusChanged(NMapPOIdataOverlay nMapPOIdataOverlay, NMapPOIitem nMapPOIitem) {

            }

            @Override
            public void onCalloutClick(NMapPOIdataOverlay nMapPOIdataOverlay, NMapPOIitem nMapPOIitem) {
                Intent intent = new Intent(MainActivity.this, SubActivity.class);
                intent.putExtra("courseid", api.getCourseId().get(nMapPOIitem.getId()));
                intent.putExtra("area", api.getArea().get(nMapPOIitem.getId()));
                startActivityForResult(intent, 100);
            }
        }); //POI �������� ���� ���� ���� �� ȣ��Ǵ� �ݹ� �������̽��� �����Ѵ�.

        //locationManager(��ġ�Ŵ���)
        //mMapLocationManager = new NMapLocationManager(this);
        //mMapLocationManager.setOnLocationChangeListener(onMyLocationChangeListener);

        // compass manager(��ħ�� �Ŵ���)
        mMapCompassManager = new NMapCompassManager(this);
        // create my location overlay(�� ��ġ ��������)
        //mMyLocationOverlay = mOverlayManager.createMyLocationOverlay(mMapLocationManager, mMapCompassManager);//**mMyLocationOverlay �ʱ�ȭ�ؾ���

//        editText = (EditText)findViewById(R.id.editText);
//        btn_back = (ImageButton)findViewById(R.id.btn_back);
//        str_text = editText.getText().toString();
    }

    public class ApiExplorer extends AsyncTask<Integer, Integer, Integer> {
        public final static String ENDPOINT = "http://newsky2.kma.go.kr/service/TourSpotInfoService/SpotShrtData";
        public final static String KEY = "xRn%2B2vuY8tVScvXB9m8vmb1pYQu2evJIgZ2kJR6bj9Zgr4r4Z8vX2Iqxk%2B4mzEEJXynyGGPdNpfHuc%2Fjs56WMg%3D%3D";
        Vector<Element> list = new Vector<Element>();
        ArrayList<String> area = new ArrayList<String>();
        ArrayList<String> weather = new ArrayList<String>();
        ArrayList<String> courseId = new ArrayList<String>();
        ArrayList<String> courseName = new ArrayList<String>();
        public ArrayList<String> getArea() {
            return area;
        }

        public ArrayList<String> getWeather() {
            return weather;
        }

        public ArrayList<String> getCourseId() {return courseId;}
        public ArrayList<String> getCourseName() {return courseName;}
        public void setArea(ArrayList<String> area_p) {
            area = area_p;
        }

        public void setWeather(ArrayList<String> weather_p) {
            weather = weather_p;
        }

        public void setCourseId(ArrayList<String> id_p) {
            courseId = id_p;
        }
        public void setCourseName(ArrayList<String> course_p) {courseName = course_p;}

        @Override
        protected Integer doInBackground(Integer... integers) {
            try {
                apiParserSearch();
            } catch (Exception e) {
                // TODO Auto-generated catch block
                Log.d("myLog", "error");
                e.printStackTrace();
            }
            getValues();

            return null;
        }

        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);
            SharedPreferences.Editor editor = pref.edit();
            if (!pref.contains("*")) {
                findGeoPoint();
                editor.putString("*", "*");
                editor.commit();
            }
            drawButton();
        }

        /**
         * @throws Exception
         */
        public void apiParserSearch() throws Exception {
            ArrayList<String> rvalUrl;
            rvalUrl = getURLParam(null);
            int scope = 438;
            if (pref.contains("*")) scope = pref.getInt("locationSize", 0);
            //scope = 20;//*********************
            try {
                System.out.println("connect");
                SAXBuilder parser = new SAXBuilder();
                System.out.println("SAX success");
                parser.setIgnoringElementContentWhitespace(true);
                for (int index = 0; index < scope; index++) {
                    Document doc = parser.build(new URL(rvalUrl.get(index)));
                    Log.d("rvalurl", rvalUrl.get(index));
                    Element response = doc.getRootElement();
                    //Element header = response.getChild("header");
                    Element body = response.getChild("body");
                    Element items = body.getChild("items");
                    List<Element> item = items.getChildren("item");

                    if (item.size() == 0) {
                        System.out.println("empty");
                    } else {
                        for (int i = 0; i < item.size(); i++) {
                            list.add(item.get(i));
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public ArrayList<String> getURLParam(String search) throws UnsupportedEncodingException {
            String url = ENDPOINT + "?ServiceKey=" + KEY;
            ArrayList<String> endpointurl = new ArrayList<String>();
            long now = System.currentTimeMillis();
            Date date = new Date(now);
            Log.d("myLog", "test");
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHH");
            String getTime = sdf.format(date);
            String courseId;
            int scope = 438;
            if (pref.contains("*")) scope = pref.getInt("locationSize", 0);
            //scope = 20;//*************************
            if ((Integer.parseInt(getTime) % 100) % 3 == 1)
                getTime = Integer.toString(Integer.parseInt(getTime) - 1);
            else if ((Integer.parseInt(getTime) % 100) % 3 == 2)
                getTime = Integer.toString(Integer.parseInt(getTime) - 2);
            SharedPreferences.Editor editor = pref.edit();
            editor.putString("getTime", getTime);
            editor.commit();
            for (Integer i = 1; i <= scope; i++) {
                if (!pref.contains("*")) {
                    endpointurl.add(url + "&HOUR=-23&COURSE_ID=" + i.toString() + "&pageNo=1&startPage=1&numOfRows=20&pageSize=10&CURRENT_DATE=" + getTime);
                } else {
                    courseId = pref.getString("courseId" + Integer.toString(i-1), "");
                    endpointurl.add(url + "&HOUR=-23&COURSE_ID=" + courseId + "&pageNo=1&startPage=1&numOfRows=20&pageSize=10&CURRENT_DATE=" + getTime);
                }
            }

            if (search != null) {
                url = url + "&yadmNm" + search;
            }
            return endpointurl;
        }

        public void getValues() {
            SharedPreferences.Editor editor = pref.edit();
            Integer count = 0;
            for (Integer i = 0; i < list.size(); i++) {
                Element element = list.get(i);
                Element spotAreaName = element.getChild("spotAreaName");
                Element courseAreaName = element.getChild("courseAreaName");
                Element sky = element.getChild("sky");
                Element id = element.getChild("courseId");
                Element course = element.getChild("courseName");
                if(!area.contains(courseAreaName.getValue() + " " + spotAreaName.getValue())){
                    courseName.add(course.getValue());
                    courseId.add(id.getValue());
                    area.add(courseAreaName.getValue() + " " + spotAreaName.getValue());
                    weather.add(sky.getValue());
                    editor.putString("courseName" + count.toString(), course.getValue());
                    editor.putString("area" + count.toString(), courseAreaName.getValue() + " " + spotAreaName.getValue());
                    editor.putString("weather" + count.toString(), sky.getValue());
                    editor.putString("courseId" + count.toString(), id.getValue());
                    count++;
                }
            }
            editor.commit();
        }
    }
}
